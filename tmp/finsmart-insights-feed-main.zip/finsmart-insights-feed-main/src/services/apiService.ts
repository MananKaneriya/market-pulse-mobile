
// API Keys Management Service
export class ApiService {
  private static readonly STORAGE_KEYS = {
    OPENAI_KEY: 'finsmart-openai-key',
    YAHOO_FINANCE_KEY: 'finsmart-yahoo-finance-key',
    TWITTER_KEY: 'finsmart-twitter-key'
  };

  // OpenAI API
  static getOpenAIKey(): string | null {
    return localStorage.getItem(this.STORAGE_KEYS.OPENAI_KEY);
  }

  static setOpenAIKey(key: string): void {
    localStorage.setItem(this.STORAGE_KEYS.OPENAI_KEY, key);
  }

  // Yahoo Finance API
  static getYahooFinanceKey(): string | null {
    return localStorage.getItem(this.STORAGE_KEYS.YAHOO_FINANCE_KEY);
  }

  static setYahooFinanceKey(key: string): void {
    localStorage.setItem(this.STORAGE_KEYS.YAHOO_FINANCE_KEY, key);
  }

  // Twitter API
  static getTwitterKey(): string | null {
    return localStorage.getItem(this.STORAGE_KEYS.TWITTER_KEY);
  }

  static setTwitterKey(key: string): void {
    localStorage.setItem(this.STORAGE_KEYS.TWITTER_KEY, key);
  }

  // Check if all keys are configured
  static areKeysConfigured(): boolean {
    return !!(this.getOpenAIKey() && this.getYahooFinanceKey() && this.getTwitterKey());
  }

  // OpenAI Chat Completion
  static async getChatCompletion(prompt: string): Promise<any> {
    const apiKey = this.getOpenAIKey();
    if (!apiKey) throw new Error('OpenAI API key not configured');

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 150,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch from OpenAI');
    }

    return response.json();
  }

  // Yahoo Finance Stock Data
  static async getStockData(symbol: string): Promise<any> {
    const apiKey = this.getYahooFinanceKey();
    if (!apiKey) throw new Error('Yahoo Finance API key not configured');

    const response = await fetch(`https://yahoo-finance-real-time1.p.rapidapi.com/stock/get-stock-data?symbol=${symbol}`, {
      method: 'GET',
      headers: {
        'x-rapidapi-key': apiKey,
        'x-rapidapi-host': 'yahoo-finance-real-time1.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch stock data');
    }

    return response.json();
  }

  // Yahoo Finance Stock Options
  static async getStockOptions(symbol: string): Promise<any> {
    const apiKey = this.getYahooFinanceKey();
    if (!apiKey) throw new Error('Yahoo Finance API key not configured');

    const response = await fetch(`https://yahoo-finance-real-time1.p.rapidapi.com/stock/get-options?symbol=${symbol}&lang=en-US&region=US`, {
      method: 'GET',
      headers: {
        'x-rapidapi-key': apiKey,
        'x-rapidapi-host': 'yahoo-finance-real-time1.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch stock options');
    }

    return response.json();
  }

  // Financial News Analysis using OpenAI
  static async analyzeStockNews(stockSymbol: string, newsText: string): Promise<string> {
    const prompt = `Analyze this news about ${stockSymbol}: "${newsText}". Provide a brief sentiment analysis and investment insight in 50 words or less.`;
    
    try {
      const response = await this.getChatCompletion(prompt);
      return response.choices[0]?.message?.content || 'Analysis unavailable';
    } catch (error) {
      console.error('Error analyzing news:', error);
      return 'Analysis temporarily unavailable';
    }
  }

  // Generate Financial Tips using OpenAI
  static async generateFinancialTip(): Promise<string> {
    const prompt = "Generate a practical financial tip for stock market investors in 40 words or less.";
    
    try {
      const response = await this.getChatCompletion(prompt);
      return response.choices[0]?.message?.content || 'Stay diversified and invest for the long term.';
    } catch (error) {
      console.error('Error generating tip:', error);
      return 'Always do your research before investing and consider your risk tolerance.';
    }
  }
}
