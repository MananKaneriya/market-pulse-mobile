
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ApiService } from '@/services/apiService';

export const useStockData = (symbol: string) => {
  return useQuery({
    queryKey: ['stockData', symbol],
    queryFn: () => ApiService.getStockData(symbol),
    enabled: !!symbol && ApiService.areKeysConfigured(),
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
  });
};

export const useStockOptions = (symbol: string) => {
  return useQuery({
    queryKey: ['stockOptions', symbol],
    queryFn: () => ApiService.getStockOptions(symbol),
    enabled: !!symbol && ApiService.areKeysConfigured(),
    staleTime: 10 * 60 * 1000, // 10 minutes
    retry: 2,
  });
};

export const useFinancialTip = () => {
  return useQuery({
    queryKey: ['financialTip'],
    queryFn: () => ApiService.generateFinancialTip(),
    enabled: ApiService.areKeysConfigured(),
    staleTime: 24 * 60 * 60 * 1000, // 24 hours
    retry: 1,
  });
};
