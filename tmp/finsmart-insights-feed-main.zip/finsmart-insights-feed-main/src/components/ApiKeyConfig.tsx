
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Key, CheckCircle } from 'lucide-react';
import { ApiService } from '@/services/apiService';
import { toast } from 'sonner';

const ApiKeyConfig = () => {
  const [showKeys, setShowKeys] = useState(false);
  const [keys, setKeys] = useState({
    openai: '',
    yahooFinance: '',
    twitter: ''
  });
  const [isConfigured, setIsConfigured] = useState(false);

  useEffect(() => {
    // Load existing keys
    setKeys({
      openai: ApiService.getOpenAIKey() || '',
      yahooFinance: ApiService.getYahooFinanceKey() || '',
      twitter: ApiService.getTwitterKey() || ''
    });
    setIsConfigured(ApiService.areKeysConfigured());
  }, []);

  const handleSaveKeys = () => {
    if (!keys.openai || !keys.yahooFinance || !keys.twitter) {
      toast.error('Please fill in all API keys');
      return;
    }

    ApiService.setOpenAIKey(keys.openai);
    ApiService.setYahooFinanceKey(keys.yahooFinance);
    ApiService.setTwitterKey(keys.twitter);
    
    setIsConfigured(true);
    toast.success('API keys saved successfully!');
  };

  const handleKeyChange = (field: string, value: string) => {
    setKeys(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Key className="h-5 w-5" />
          <span>API Configuration</span>
          {isConfigured && <CheckCircle className="h-5 w-5 text-fintech-green" />}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="openai-key">OpenAI API Key</Label>
          <div className="relative">
            <Input
              id="openai-key"
              type={showKeys ? "text" : "password"}
              value={keys.openai}
              onChange={(e) => handleKeyChange('openai', e.target.value)}
              placeholder="sk-proj-..."
              className="pr-10"
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3"
              onClick={() => setShowKeys(!showKeys)}
            >
              {showKeys ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="yahoo-key">Yahoo Finance API Key (RapidAPI)</Label>
          <Input
            id="yahoo-key"
            type={showKeys ? "text" : "password"}
            value={keys.yahooFinance}
            onChange={(e) => handleKeyChange('yahooFinance', e.target.value)}
            placeholder="x-rapidapi-key..."
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="twitter-key">Twitter API Key</Label>
          <Input
            id="twitter-key"
            type={showKeys ? "text" : "password"}
            value={keys.twitter}
            onChange={(e) => handleKeyChange('twitter', e.target.value)}
            placeholder="Twitter API key..."
          />
        </div>

        <div className="pt-4">
          <Button onClick={handleSaveKeys} className="w-full">
            Save API Keys
          </Button>
        </div>

        <div className="text-sm text-muted-foreground">
          <p className="font-medium mb-2">Note:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>API keys are stored locally in your browser</li>
            <li>For production use, consider connecting to Supabase for secure key management</li>
            <li>Make sure your API keys have the necessary permissions</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default ApiKeyConfig;
