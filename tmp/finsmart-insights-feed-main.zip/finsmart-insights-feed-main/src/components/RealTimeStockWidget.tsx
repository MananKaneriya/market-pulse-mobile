
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { useStockData } from '@/hooks/useStockData';
import { ApiService } from '@/services/apiService';

interface RealTimeStockWidgetProps {
  symbol: string;
  companyName: string;
}

const RealTimeStockWidget = ({ symbol, companyName }: RealTimeStockWidgetProps) => {
  const { data: stockData, isLoading, error } = useStockData(symbol);

  if (!ApiService.areKeysConfigured()) {
    return (
      <Card className="w-full">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground">
            Configure API keys to view real-time data
          </p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="p-4">
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full border-red-200">
        <CardContent className="p-4">
          <p className="text-sm text-red-600">
            Failed to load real-time data for {symbol}
          </p>
        </CardContent>
      </Card>
    );
  }

  // Mock data structure - adjust based on actual Yahoo Finance API response
  const price = stockData?.price || 0;
  const change = stockData?.change || 0;
  const changePercent = stockData?.changePercent || 0;
  const isPositive = change >= 0;

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center justify-between">
          <span>{companyName}</span>
          <Badge variant="outline" className="text-xs">
            {symbol}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-2xl font-bold">₹{price.toFixed(2)}</p>
            <div className={`flex items-center space-x-1 text-sm ${
              isPositive ? 'text-fintech-green' : 'text-fintech-red'
            }`}>
              {isPositive ? (
                <TrendingUp className="h-3 w-3" />
              ) : (
                <TrendingDown className="h-3 w-3" />
              )}
              <span>{isPositive ? '+' : ''}{change.toFixed(2)}</span>
              <span>({isPositive ? '+' : ''}{changePercent.toFixed(2)}%)</span>
            </div>
          </div>
          <Activity className="h-8 w-8 text-fintech-blue opacity-20" />
        </div>
      </CardContent>
    </Card>
  );
};

export default RealTimeStockWidget;
