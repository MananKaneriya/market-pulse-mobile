
import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lightbulb, X, RefreshCw } from 'lucide-react';
import { useFinancialTip } from '@/hooks/useStockData';

const FinancialTipWidget = () => {
  const [isVisible, setIsVisible] = useState(true);
  const { data: tip, isLoading, refetch } = useFinancialTip();

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-20 left-4 md:bottom-4 z-40 max-w-xs">
      <Card className="shadow-lg border-fintech-gold/20 bg-gradient-to-r from-fintech-gold/10 to-fintech-blue/10">
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <div className="flex items-center space-x-2">
              <Lightbulb className="h-4 w-4 text-fintech-gold" />
              <span className="text-sm font-medium">Daily Tip</span>
            </div>
            <div className="flex space-x-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => refetch()}
                className="h-auto p-1"
                disabled={isLoading}
              >
                <RefreshCw className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsVisible(false)}
                className="h-auto p-1"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>
          
          <p className="text-sm text-foreground/80">
            {isLoading ? 'Generating tip...' : tip || 'Always diversify your portfolio and invest for the long term.'}
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancialTipWidget;
