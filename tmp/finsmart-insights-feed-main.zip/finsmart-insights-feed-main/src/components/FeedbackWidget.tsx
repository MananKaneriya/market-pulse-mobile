
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThumbsUp, ThumbsDown, Meh, MessageSquare, X } from 'lucide-react';
import { toast } from 'sonner';

const FeedbackWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [feedback, setFeedback] = useState<'positive' | 'negative' | 'neutral' | null>(null);

  const handleFeedback = (type: 'positive' | 'negative' | 'neutral') => {
    setFeedback(type);
    toast.success('Thank you for your feedback!');
    setTimeout(() => {
      setIsOpen(false);
      setFeedback(null);
    }, 1500);
  };

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 right-4 md:bottom-4 rounded-full w-12 h-12 bg-fintech-blue hover:bg-fintech-blue/90 shadow-lg"
        size="sm"
      >
        <MessageSquare className="h-5 w-5" />
      </Button>
    );
  }

  return (
    <div className="fixed bottom-20 right-4 md:bottom-4 z-50">
      <Card className="w-64 shadow-lg">
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-3">
            <h4 className="font-medium">How's your experience?</h4>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="h-auto p-1"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
          
          {!feedback && (
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleFeedback('positive')}
                className="flex-1 hover:bg-green-50 hover:border-green-200"
              >
                <ThumbsUp className="h-4 w-4 mr-1" />
                Good
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleFeedback('neutral')}
                className="flex-1 hover:bg-yellow-50 hover:border-yellow-200"
              >
                <Meh className="h-4 w-4 mr-1" />
                Okay
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleFeedback('negative')}
                className="flex-1 hover:bg-red-50 hover:border-red-200"
              >
                <ThumbsDown className="h-4 w-4 mr-1" />
                Poor
              </Button>
            </div>
          )}

          {feedback && (
            <div className="text-center">
              <div className="text-green-600 mb-2">
                {feedback === 'positive' && <ThumbsUp className="h-6 w-6 mx-auto" />}
                {feedback === 'neutral' && <Meh className="h-6 w-6 mx-auto" />}
                {feedback === 'negative' && <ThumbsDown className="h-6 w-6 mx-auto" />}
              </div>
              <p className="text-sm text-muted-foreground">Feedback recorded!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default FeedbackWidget;
