
export interface Company {
  id: string;
  name: string;
  symbol: string;
  sector: string;
  currentPrice: number;
  change: number;
  changePercent: number;
}

export interface NewsItem {
  id: string;
  title: string;
  content: string;
  source: string;
  timestamp: string;
  relatedCompanies: string[];
  sentiment: 'positive' | 'negative' | 'neutral';
  likes: number;
  comments: Comment[];
  isBookmarked: boolean;
}

export interface Comment {
  id: string;
  user: string;
  content: string;
  timestamp: string;
  likes: number;
}

export interface FinancialTip {
  id: string;
  title: string;
  content: string;
  category: string;
}

export const indianStockCompanies: Company[] = [
  { id: '1', name: 'Reliance Industries', symbol: 'RELIANCE', sector: 'Energy', currentPrice: 2456.30, change: 45.20, changePercent: 1.87 },
  { id: '2', name: 'Tata Consultancy Services', symbol: 'TCS', sector: 'IT', currentPrice: 3789.50, change: -23.10, changePercent: -0.61 },
  { id: '3', name: 'HDFC Bank', symbol: 'HDFCBANK', sector: 'Banking', currentPrice: 1654.80, change: 12.45, changePercent: 0.76 },
  { id: '4', name: 'Infosys', symbol: 'INFY', sector: 'IT', currentPrice: 1423.90, change: 8.70, changePercent: 0.62 },
  { id: '5', name: 'Hindustan Unilever', symbol: 'HINDUNILVR', sector: 'FMCG', currentPrice: 2678.40, change: -15.60, changePercent: -0.58 },
  { id: '6', name: 'ITC', symbol: 'ITC', sector: 'FMCG', currentPrice: 456.25, change: 3.80, changePercent: 0.84 },
  { id: '7', name: 'ICICI Bank', symbol: 'ICICIBANK', sector: 'Banking', currentPrice: 987.60, change: 18.90, changePercent: 1.95 },
  { id: '8', name: 'State Bank of India', symbol: 'SBIN', sector: 'Banking', currentPrice: 623.45, change: -7.25, changePercent: -1.15 },
  { id: '9', name: 'Bharti Airtel', symbol: 'BHARTIARTL', sector: 'Telecom', currentPrice: 1234.70, change: 21.40, changePercent: 1.76 },
  { id: '10', name: 'Wipro', symbol: 'WIPRO', sector: 'IT', currentPrice: 567.80, change: -4.50, changePercent: -0.79 },
];

export const dummyNews: NewsItem[] = [
  {
    id: '1',
    title: 'Reliance Industries reports strong Q3 earnings',
    content: 'Reliance Industries posted impressive quarterly results with revenue growth of 15% YoY. The petrochemicals division showed robust performance while Jio continues its digital expansion.',
    source: 'Economic Times',
    timestamp: '2 hours ago',
    relatedCompanies: ['RELIANCE'],
    sentiment: 'positive',
    likes: 124,
    comments: [
      { id: '1', user: 'investor_raj', content: 'Great results! Bullish on RIL', timestamp: '1 hour ago', likes: 23 },
      { id: '2', user: 'market_guru', content: 'Jio growth is impressive', timestamp: '45 min ago', likes: 15 }
    ],
    isBookmarked: false
  },
  {
    id: '2',
    title: 'IT sector faces headwinds amid global uncertainty',
    content: 'Leading IT companies including TCS and Infosys are navigating through challenging times with reduced client spending and delayed project implementations.',
    source: 'Business Standard',
    timestamp: '4 hours ago',
    relatedCompanies: ['TCS', 'INFY', 'WIPRO'],
    sentiment: 'negative',
    likes: 87,
    comments: [
      { id: '3', user: 'tech_analyst', content: 'Temporary headwinds, long term still positive', timestamp: '2 hours ago', likes: 41 }
    ],
    isBookmarked: false
  },
  {
    id: '3',
    title: 'Banking sector shows resilience with improving asset quality',
    content: 'Major banks including HDFC Bank and ICICI Bank report better-than-expected asset quality metrics. NPAs continue to decline across the sector.',
    source: 'Mint',
    timestamp: '6 hours ago',
    relatedCompanies: ['HDFCBANK', 'ICICIBANK', 'SBIN'],
    sentiment: 'positive',
    likes: 156,
    comments: [],
    isBookmarked: true
  }
];

export const financialTips: FinancialTip[] = [
  {
    id: '1',
    title: 'Diversification is Key',
    content: 'Don\'t put all your eggs in one basket. Spread your investments across different sectors and asset classes to reduce risk.',
    category: 'Risk Management'
  },
  {
    id: '2',
    title: 'Start SIP Early',
    content: 'Time is your best friend in investing. Starting a SIP early allows you to benefit from the power of compounding.',
    category: 'Investment Strategy'
  },
  {
    id: '3',
    title: 'Emergency Fund First',
    content: 'Before investing, ensure you have 6-12 months of expenses saved as an emergency fund in liquid instruments.',
    category: 'Financial Planning'
  }
];
