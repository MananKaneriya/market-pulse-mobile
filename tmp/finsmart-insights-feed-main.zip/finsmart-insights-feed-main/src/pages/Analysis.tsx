
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Activity } from 'lucide-react';
import { indianStockCompanies } from '@/data/dummyData';
import Navbar from '@/components/Navbar';
import FeedbackWidget from '@/components/FeedbackWidget';

const Analysis = () => {
  const [selectedCompany, setSelectedCompany] = useState('RELIANCE');
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);

  useEffect(() => {
    // Get user's selected companies from localStorage
    const saved = localStorage.getItem('finsmart-selected-companies');
    if (saved) {
      setSelectedCompanies(JSON.parse(saved));
    }
  }, []);

  // Dummy chart data
  const priceData = [
    { name: 'Jan', price: 2400, volume: 1200 },
    { name: 'Feb', price: 2410, volume: 1300 },
    { name: 'Mar', price: 2380, volume: 1100 },
    { name: 'Apr', price: 2420, volume: 1400 },
    { name: 'May', price: 2456, volume: 1250 },
  ];

  const sectorData = [
    { name: 'IT', value: 30, color: '#1E40AF' },
    { name: 'Banking', value: 25, color: '#059669' },
    { name: 'Energy', value: 20, color: '#F59E0B' },
    { name: 'FMCG', value: 15, color: '#DC2626' },
    { name: 'Telecom', value: 10, color: '#7C3AED' },
  ];

  const performanceData = indianStockCompanies
    .filter(company => selectedCompanies.includes(company.id))
    .map(company => ({
      name: company.symbol,
      return: company.changePercent,
      price: company.currentPrice,
    }));

  const sentimentData = [
    { name: 'Mon', positive: 65, negative: 20, neutral: 15 },
    { name: 'Tue', positive: 72, negative: 18, neutral: 10 },
    { name: 'Wed', positive: 58, negative: 30, neutral: 12 },
    { name: 'Thu', positive: 68, negative: 22, neutral: 10 },
    { name: 'Fri', positive: 75, negative: 15, neutral: 10 },
  ];

  const selectedCompanyData = indianStockCompanies.find(c => c.symbol === selectedCompany);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Market Analysis</h1>
          <Select value={selectedCompany} onValueChange={setSelectedCompany}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select company" />
            </SelectTrigger>
            <SelectContent>
              {indianStockCompanies
                .filter(company => selectedCompanies.includes(company.id))
                .map((company) => (
                <SelectItem key={company.symbol} value={company.symbol}>
                  {company.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4 text-fintech-green" />
                <span className="text-sm text-muted-foreground">Current Price</span>
              </div>
              <p className="text-2xl font-bold">₹{selectedCompanyData?.currentPrice.toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                {selectedCompanyData && selectedCompanyData.change >= 0 ? (
                  <TrendingUp className="h-4 w-4 text-fintech-green" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-fintech-red" />
                )}
                <span className="text-sm text-muted-foreground">Day Change</span>
              </div>
              <p className={`text-2xl font-bold ${
                selectedCompanyData && selectedCompanyData.change >= 0 ? 'text-fintech-green' : 'text-fintech-red'
              }`}>
                {selectedCompanyData?.changePercent.toFixed(2)}%
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Activity className="h-4 w-4 text-fintech-blue" />
                <span className="text-sm text-muted-foreground">Volatility</span>
              </div>
              <p className="text-2xl font-bold">2.3%</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-fintech-gold" />
                <span className="text-sm text-muted-foreground">RSI</span>
              </div>
              <p className="text-2xl font-bold">68.5</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <Tabs defaultValue="price" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="price">Price Chart</TabsTrigger>
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
            <TabsTrigger value="sector">Sector Analysis</TabsTrigger>
            <TabsTrigger value="sentiment">Sentiment</TabsTrigger>
          </TabsList>

          <TabsContent value="price" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Price Movement - {selectedCompany}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={priceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="price" 
                        stroke="#1E40AF" 
                        strokeWidth={2}
                        dot={{ fill: '#1E40AF' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Volume Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={priceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="volume" fill="#059669" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="portfolio" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Portfolio Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar 
                        dataKey="return" 
                        fill="#1E40AF"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sector" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Sector Allocation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={sectorData}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {sectorData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sentiment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Social Media Sentiment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sentimentData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="positive" stackId="a" fill="#059669" />
                      <Bar dataKey="neutral" stackId="a" fill="#F59E0B" />
                      <Bar dataKey="negative" stackId="a" fill="#DC2626" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <FeedbackWidget />
    </div>
  );
};

export default Analysis;
