
import { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, MessageCircle, Share, Bookmark, Search, TrendingUp } from 'lucide-react';
import { dummyNews, type NewsItem } from '@/data/dummyData';
import { toast } from 'sonner';
import Navbar from '@/components/Navbar';
import FeedbackWidget from '@/components/FeedbackWidget';

const Bookmarks = () => {
  const [bookmarkedItems, setBookmarkedItems] = useState<NewsItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredItems, setFilteredItems] = useState<NewsItem[]>([]);

  useEffect(() => {
    // Filter bookmarked items from dummy data
    const bookmarked = dummyNews.filter(item => item.isBookmarked);
    setBookmarkedItems(bookmarked);
    setFilteredItems(bookmarked);
  }, []);

  useEffect(() => {
    // Filter items based on search term
    if (searchTerm.trim() === '') {
      setFilteredItems(bookmarkedItems);
    } else {
      const filtered = bookmarkedItems.filter(item =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.relatedCompanies.some(company => 
          company.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
      setFilteredItems(filtered);
    }
  }, [searchTerm, bookmarkedItems]);

  const handleRemoveBookmark = (newsId: string) => {
    setBookmarkedItems(prev => prev.filter(item => item.id !== newsId));
    setFilteredItems(prev => prev.filter(item => item.id !== newsId));
    toast.success('Removed from bookmarks');
  };

  const handleShare = (newsItem: NewsItem) => {
    if (navigator.share) {
      navigator.share({
        title: newsItem.title,
        text: newsItem.content,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(`${newsItem.title}\n\n${newsItem.content}`);
      toast.success('Copied to clipboard');
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-fintech-green';
      case 'negative': return 'text-fintech-red';
      default: return 'text-gray-500';
    }
  };

  const getSentimentBg = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'bg-fintech-green/10 border-fintech-green/20';
      case 'negative': return 'bg-fintech-red/10 border-fintech-red/20';
      default: return 'bg-gray-100 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Bookmarks</h1>
          <div className="text-sm text-muted-foreground">
            {filteredItems.length} saved article{filteredItems.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search bookmarked articles..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Bookmarked Items */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-12">
            <Bookmark className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">
              {searchTerm ? 'No matching bookmarks' : 'No bookmarks yet'}
            </h3>
            <p className="text-muted-foreground">
              {searchTerm 
                ? 'Try adjusting your search terms' 
                : 'Save articles you want to read later by tapping the bookmark icon'
              }
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredItems.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-200">
                <CardContent className="p-0">
                  {/* Header */}
                  <div className="p-4 border-b">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-fintech-blue rounded-full flex items-center justify-center">
                          <TrendingUp className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">{item.source}</p>
                          <p className="text-xs text-muted-foreground">{item.timestamp}</p>
                        </div>
                      </div>
                      <div className={`px-2 py-1 rounded-full text-xs border ${getSentimentBg(item.sentiment)}`}>
                        <span className={getSentimentColor(item.sentiment)}>
                          {item.sentiment.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                    <p className="text-muted-foreground mb-3">{item.content}</p>
                    
                    {/* Related Companies */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {item.relatedCompanies.map((company) => (
                        <span 
                          key={company} 
                          className="text-xs bg-fintech-blue/10 text-fintech-blue px-2 py-1 rounded-full"
                        >
                          ${company}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="px-4 pb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Button variant="ghost" size="sm" className="hover:bg-red-50">
                          <Heart className="h-4 w-4 mr-1" />
                          {item.likes}
                        </Button>
                        
                        <Button variant="ghost" size="sm" className="hover:bg-blue-50">
                          <MessageCircle className="h-4 w-4 mr-1" />
                          {item.comments.length}
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => handleShare(item)}
                          className="hover:bg-green-50"
                        >
                          <Share className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveBookmark(item.id)}
                        className="hover:bg-yellow-50 text-yellow-600"
                      >
                        <Bookmark className="h-4 w-4 fill-current" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <FeedbackWidget />
    </div>
  );
};

export default Bookmarks;
