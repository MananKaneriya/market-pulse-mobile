
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { TrendingUp, Shield, Zap, BarChart3 } from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user has completed onboarding
    const hasCompletedOnboarding = localStorage.getItem('finsmart-onboarding-complete');
    if (hasCompletedOnboarding) {
      navigate('/home');
    }
  }, [navigate]);

  const handleGetStarted = () => {
    navigate('/onboarding');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-fintech-blue via-fintech-blue-light to-fintech-green text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-16">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-8 w-8" />
            <h1 className="text-2xl font-bold">FinSmart</h1>
          </div>
        </div>

        {/* Hero Section */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            Smart Financial
            <br />
            <span className="text-fintech-gold">Decisions</span>
          </h2>
          <p className="text-xl md:text-2xl mb-8 opacity-90 max-w-2xl mx-auto">
            Get AI-powered insights, real-time analysis, and social sentiment for your Indian stock portfolio
          </p>
          <Button 
            onClick={handleGetStarted}
            className="bg-white text-fintech-blue hover:bg-gray-100 text-lg px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:scale-105"
          >
            Get Started
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="text-center p-6 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-all duration-300">
            <BarChart3 className="h-12 w-12 mx-auto mb-4 text-fintech-gold" />
            <h3 className="text-xl font-semibold mb-2">Advanced Analytics</h3>
            <p className="opacity-80">Get detailed technical and fundamental analysis of your stocks with interactive charts and graphs.</p>
          </div>
          
          <div className="text-center p-6 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-all duration-300">
            <Zap className="h-12 w-12 mx-auto mb-4 text-fintech-gold" />
            <h3 className="text-xl font-semibold mb-2">Real-time News</h3>
            <p className="opacity-80">Stay updated with latest news, social media sentiment, and expert analysis for your portfolio.</p>
          </div>
          
          <div className="text-center p-6 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-all duration-300">
            <Shield className="h-12 w-12 mx-auto mb-4 text-fintech-gold" />
            <h3 className="text-xl font-semibold mb-2">AI-Powered Insights</h3>
            <p className="opacity-80">Leverage cutting-edge AI for personalized investment recommendations and market predictions.</p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center opacity-60">
          <p>&copy; 2024 FinSmart. Empowering smart financial decisions.</p>
        </div>
      </div>
    </div>
  );
};

export default Index;
