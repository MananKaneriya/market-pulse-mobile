import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, MessageCircle, Share, Bookmark, TrendingUp, X } from 'lucide-react';
import { dummyNews, financialTips, type NewsItem } from '@/data/dummyData';
import { toast } from 'sonner';
import Navbar from '@/components/Navbar';
import FeedbackWidget from '@/components/FeedbackWidget';
import FinancialTipWidget from '@/components/FinancialTipWidget';

const Home = () => {
  const [newsItems, setNewsItems] = useState<NewsItem[]>(dummyNews);
  const [showTip, setShowTip] = useState(false);
  const [currentTip, setCurrentTip] = useState(financialTips[0]);
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());

  useEffect(() => {
    // Show daily tip after 2 seconds
    const timer = setTimeout(() => {
      setShowTip(true);
      const randomTip = financialTips[Math.floor(Math.random() * financialTips.length)];
      setCurrentTip(randomTip);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const handleLike = (newsId: string) => {
    setLikedPosts(prev => {
      const newLiked = new Set(prev);
      if (newLiked.has(newsId)) {
        newLiked.delete(newsId);
      } else {
        newLiked.add(newsId);
      }
      return newLiked;
    });

    setNewsItems(prev => prev.map(item => 
      item.id === newsId 
        ? { ...item, likes: likedPosts.has(newsId) ? item.likes - 1 : item.likes + 1 }
        : item
    ));
  };

  const handleBookmark = (newsId: string) => {
    setNewsItems(prev => prev.map(item => 
      item.id === newsId 
        ? { ...item, isBookmarked: !item.isBookmarked }
        : item
    ));

    const item = newsItems.find(item => item.id === newsId);
    if (item) {
      toast.success(item.isBookmarked ? 'Removed from bookmarks' : 'Added to bookmarks');
    }
  };

  const handleShare = (newsItem: NewsItem) => {
    if (navigator.share) {
      navigator.share({
        title: newsItem.title,
        text: newsItem.content,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(`${newsItem.title}\n\n${newsItem.content}`);
      toast.success('Copied to clipboard');
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-fintech-green';
      case 'negative': return 'text-fintech-red';
      default: return 'text-gray-500';
    }
  };

  const getSentimentBg = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'bg-fintech-green/10 border-fintech-green/20';
      case 'negative': return 'bg-fintech-red/10 border-fintech-red/20';
      default: return 'bg-gray-100 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <div className="container mx-auto px-4 py-6">
        {/* Welcome Section */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Welcome to Fintech News</h1>
            <Button variant="ghost" size="sm" className="hover:bg-blue-50">
              <MessageCircle className="h-4 w-4 mr-1" />
              <span className="text-xs text-muted-foreground">Subscribe</span>
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-fintech-blue rounded-full flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="font-medium text-sm">Total News</p>
                <p className="text-xs text-muted-foreground">1000</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-fintech-green rounded-full flex items-center justify-center">
                <Heart className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="font-medium text-sm">Total Likes</p>
                <p className="text-xs text-muted-foreground">5000</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-fintech-red rounded-full flex items-center justify-center">
                <MessageCircle className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="font-medium text-sm">Total Comments</p>
                <p className="text-xs text-muted-foreground">2000</p>
              </div>
            </div>
          </div>
        </div>

        {/* Portfolio Overview */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-fintech-blue rounded-full flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="font-medium text-sm">Portfolio Value</p>
                <p className="text-xs text-muted-foreground">$100,000</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-fintech-green rounded-full flex items-center justify-center">
                <Heart className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="font-medium text-sm">Total Portfolio Likes</p>
                <p className="text-xs text-muted-foreground">500</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-fintech-red rounded-full flex items-center justify-center">
                <MessageCircle className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="font-medium text-sm">Total Portfolio Comments</p>
                <p className="text-xs text-muted-foreground">100</p>
              </div>
            </div>
          </div>
        </div>

        {/* News Feed */}
        <div className="space-y-6">
          {newsItems.map((item) => (
            <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-200">
              <CardContent className="p-0">
                {/* Header */}
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-fintech-blue rounded-full flex items-center justify-center">
                        <TrendingUp className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{item.source}</p>
                        <p className="text-xs text-muted-foreground">{item.timestamp}</p>
                      </div>
                    </div>
                    <div className={`px-2 py-1 rounded-full text-xs border ${getSentimentBg(item.sentiment)}`}>
                      <span className={getSentimentColor(item.sentiment)}>
                        {item.sentiment.toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                  <p className="text-muted-foreground mb-3">{item.content}</p>
                  
                  {/* Related Companies */}
                  <div className="flex flex-wrap gap-1 mb-4">
                    {item.relatedCompanies.map((company) => (
                      <span 
                        key={company} 
                        className="text-xs bg-fintech-blue/10 text-fintech-blue px-2 py-1 rounded-full"
                      >
                        ${company}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="px-4 pb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLike(item.id)}
                        className={`hover:bg-red-50 ${likedPosts.has(item.id) ? 'text-red-500' : ''}`}
                      >
                        <Heart className={`h-4 w-4 mr-1 ${likedPosts.has(item.id) ? 'fill-current' : ''}`} />
                        {item.likes}
                      </Button>
                      
                      <Button variant="ghost" size="sm" className="hover:bg-blue-50">
                        <MessageCircle className="h-4 w-4 mr-1" />
                        {item.comments.length}
                      </Button>
                      
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleShare(item)}
                        className="hover:bg-green-50"
                      >
                        <Share className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleBookmark(item.id)}
                      className={`hover:bg-yellow-50 ${item.isBookmarked ? 'text-yellow-600' : ''}`}
                    >
                      <Bookmark className={`h-4 w-4 ${item.isBookmarked ? 'fill-current' : ''}`} />
                    </Button>
                  </div>

                  {/* Comments Preview */}
                  {item.comments.length > 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <div className="space-y-2">
                        {item.comments.slice(0, 2).map((comment) => (
                          <div key={comment.id} className="text-sm">
                            <span className="font-medium">{comment.user}</span>
                            <span className="ml-2 text-muted-foreground">{comment.content}</span>
                          </div>
                        ))}
                        {item.comments.length > 2 && (
                          <p className="text-xs text-muted-foreground">
                            View all {item.comments.length} comments
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Daily Tip Popup */}
      {showTip && (
        <div className="fixed bottom-4 left-4 max-w-sm z-50 animate-slide-up">
          <Card className="bg-fintech-gold shadow-lg border-fintech-gold/20">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold text-white">💡 Daily Tip</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowTip(false)}
                  className="text-white hover:bg-white/20 p-1 h-auto"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
              <h5 className="font-medium text-white mb-1">{currentTip.title}</h5>
              <p className="text-sm text-white/90">{currentTip.content}</p>
            </CardContent>
          </Card>
        </div>
      )}

      <FinancialTipWidget />
      <FeedbackWidget />
    </div>
  );
};

export default Home;
