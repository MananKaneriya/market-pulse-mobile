
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, ChevronRight } from 'lucide-react';
import { indianStockCompanies } from '@/data/dummyData';
import { toast } from 'sonner';

const Onboarding = () => {
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);
  const [currentStep, setCurrentStep] = useState(1);
  const navigate = useNavigate();

  const handleCompanyToggle = (companyId: string) => {
    setSelectedCompanies(prev => 
      prev.includes(companyId)
        ? prev.filter(id => id !== companyId)
        : [...prev, companyId]
    );
  };

  const handleContinue = () => {
    if (selectedCompanies.length === 0) {
      toast.error('Please select at least one company to continue');
      return;
    }

    // Save selected companies to localStorage
    localStorage.setItem('finsmart-selected-companies', JSON.stringify(selectedCompanies));
    localStorage.setItem('finsmart-onboarding-complete', 'true');
    
    toast.success(`${selectedCompanies.length} companies selected successfully!`);
    navigate('/home');
  };

  const groupedCompanies = indianStockCompanies.reduce((acc, company) => {
    if (!acc[company.sector]) {
      acc[company.sector] = [];
    }
    acc[company.sector].push(company);
    return acc;
  }, {} as Record<string, typeof indianStockCompanies>);

  return (
    <div className="min-h-screen bg-gradient-to-br from-fintech-blue to-fintech-green">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-2 text-white">
            <TrendingUp className="h-6 w-6" />
            <span className="text-xl font-bold">FinSmart</span>
          </div>
          <div className="text-white text-sm">
            Step {currentStep} of 1
          </div>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <Progress value={100} className="h-2" />
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-2xl">
            <CardHeader className="text-center pb-6">
              <CardTitle className="text-3xl mb-2">Select Your Portfolio</CardTitle>
              <p className="text-muted-foreground text-lg">
                Choose the Indian companies you have invested in to get personalized insights
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Object.entries(groupedCompanies).map(([sector, companies]) => (
                  <div key={sector} className="space-y-3">
                    <h3 className="text-lg font-semibold text-fintech-blue border-b pb-2">
                      {sector}
                    </h3>
                    <div className="grid md:grid-cols-2 gap-3">
                      {companies.map((company) => (
                        <div
                          key={company.id}
                          className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all duration-200 cursor-pointer hover:bg-gray-50 ${
                            selectedCompanies.includes(company.id)
                              ? 'border-fintech-green bg-fintech-green/5'
                              : 'border-gray-200'
                          }`}
                          onClick={() => handleCompanyToggle(company.id)}
                        >
                          <Checkbox
                            checked={selectedCompanies.includes(company.id)}
                            onChange={() => handleCompanyToggle(company.id)}
                          />
                          <div className="flex-1">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="font-medium">{company.name}</p>
                                <p className="text-sm text-muted-foreground">{company.symbol}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-medium">₹{company.currentPrice.toFixed(2)}</p>
                                <p className={`text-sm ${
                                  company.change >= 0 ? 'text-fintech-green' : 'text-fintech-red'
                                }`}>
                                  {company.change >= 0 ? '+' : ''}{company.changePercent.toFixed(2)}%
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  {selectedCompanies.length} companies selected
                </p>
                <Button 
                  onClick={handleContinue}
                  className="bg-fintech-green hover:bg-fintech-green/90 px-8"
                  disabled={selectedCompanies.length === 0}
                >
                  Continue to FinSmart
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
